GS Browser 
========== 
 
Installation: 
1. Install Python 3.8 or higher 
2. Run: pip install -r requirements.txt 
3. Double-click run_browser.bat to start 
